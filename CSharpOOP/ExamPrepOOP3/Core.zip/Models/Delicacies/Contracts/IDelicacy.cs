﻿namespace ChristmasPastryShop.Models.Delicacies.Contracts
{
    public interface IDelicacy
    {
        public string Name { get; }

        public double Price { get; }
    }
}
